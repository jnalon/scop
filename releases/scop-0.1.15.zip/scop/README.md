# scop
Módulo do Scop RPG para o Foundry VTT
